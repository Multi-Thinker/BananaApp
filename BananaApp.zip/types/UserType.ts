export interface User {
  bananas: number;
  lastDayPlayed: string;
  longestStreak: number;
  name: string;
  subscribed: boolean;
  uid: string;
  rank?: number;
}
